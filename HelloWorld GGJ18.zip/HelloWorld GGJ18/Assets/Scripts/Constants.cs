﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Constants : MonoBehaviour {
    public const int RIGHT = 0;
    public const int LEFT = 1;
    public const int UP = 2;
    public const int DOWN = 3;
}

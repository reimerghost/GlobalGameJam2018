﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroController : MonoBehaviour {

    public int facingDirection;

	
	void Start () {
		
	}
	
	void Update () {
		
	}
}
